/*
 * Copyright (C) 2025 AU Inc.
 *
 * Author   : AU
 * Desc     : The CAN mw acts as a bridge between the application layer and the driver hal layer.
 */

#include <stdio.h>
#include <string.h>

#include "hal/can_hal.h"
#include "mw/can_mw.h"

#include "mw/can/can_custom_tp.h"
#include "mw/can/can_isotp.h"

// Todo Device ID should be defined in EEPROM(?).
#define DEVICE_ID 0x0

void can_driver_init(void)
{
    can_set_device_id(DEVICE_ID);
    App_mcanInit();
#ifdef ISO_TP_ENABLE
    can_isotp_init();
#else
    can_custom_tp_init();
#endif
}

int32_t can_send_data(uint32_t msg_id, uint8_t* data, int32_t size)
{
#ifdef ISO_TP_ENABLE
    int32_t result = can_isotp_send_none_blocking(msg_id, data, size);
#else
    int32_t result = can_custom_tp_send(msg_id, data, size);
#endif
     printf("send_data msg_id 0x%02x size: %d\n", msg_id, size);
return result;
}

int32_t can_send_message(uint32_t msg_id, uint8_t* data, int32_t size)
{
#ifdef ISO_TP_ENABLE
    int32_t result = can_isotp_send_blocking(msg_id, data, size);
#else
    int32_t result = can_custom_tp_send(msg_id, data, size);
#endif
    //printf("can_send_message msg_id 0x%02x size: %d\n", msg_id, size);
    return result;
}
