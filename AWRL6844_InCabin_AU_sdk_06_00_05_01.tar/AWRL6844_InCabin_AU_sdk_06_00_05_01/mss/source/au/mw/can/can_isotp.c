/*
 * Copyright (C) 2025 AU Inc.
 *
 * Author   : AU
 * Desc     : The CAN mw acts as a bridge between the application layer and the driver hal layer.
 */

 #include <stdio.h>
#include <string.h>

#include "FreeRTOS.h"
#include "semphr.h"

#include "hal/can_hal.h"
#include "mw/can_mw.h"
#include "com/hexdump.h"
#include "app/rcv_message_process.h"

#include <tp/isotp-c/isotp.h>
#include "mw/can/can_isotp.h"

#define ISOTP_TX_ID  0xC8u  /* AWRL6844 -> PC */
#define ISOTP_RX_ID  0xC0u  /* PC -> AWRL6844 */

#define RX_ISOTP_BUF_SIZE     4096u
#define TX_ISOTP_BUF_SIZE     16 * 1024u

#define ISOTP_POLL_TASK_PRIO   (tskIDLE_PRIORITY + 3)
#define ISOTP_POLL_STACK_DEPTH (1024)

#define TX_BUSY_RESET_MS 1500u  /* 1.5s  */

static StaticTask_t gIsoTpPollTaskObj;
static StackType_t  gIsoTpPollTaskStack[ISOTP_POLL_STACK_DEPTH];
static TaskHandle_t gIsoTpPollTaskHandle;

static uint32_t gTxBusySinceMs = 0u;

static uint8_t  rx_buf_isotp[RX_ISOTP_BUF_SIZE];
static uint8_t  tx_buf_isotp[TX_ISOTP_BUF_SIZE];

static IsoTpLink g_link;
static uint8_t gRcvBuf[RX_ISOTP_BUF_SIZE];
static uint8_t gSendBuf[TX_ISOTP_BUF_SIZE];

static SemaphoreHandle_t gIsoTpMutex;
static StaticSemaphore_t gIsoTpMutexBuf;

static inline void isotp_lock(void)
{
    xSemaphoreTake(gIsoTpMutex, portMAX_DELAY);
}

static inline void isotp_unlock(void)
{
    xSemaphoreGive(gIsoTpMutex);
}

static void IsoTpPollTask(void *arg)
{
    (void)arg;

    for (;;) {
        isotp_lock();
        isotp_poll(&g_link);
        isotp_unlock();
        vTaskDelay(pdMS_TO_TICKS(1));
    }
}

static inline uint8_t get_send_status_locked(void) {
    uint8_t st;
    isotp_lock();
    st = g_link.send_status;
    isotp_unlock();
    return st;
}

static inline void force_full_idle_locked(void) {
    g_link.send_status    = 0u;
    g_link.send_offset    = 0u;
    g_link.send_size      = 0u;
    g_link.send_sn        = 0u;
    g_link.send_bs_remain = 0u;
    g_link.send_timer_st  = 0u;
    g_link.send_timer_bs  = 0u;
}

static void can_isotp_send_ack(const char *fmt, ...)
{
    char line[128];
    va_list ap;

    va_start(ap, fmt);
    int n = vsnprintf(line, sizeof(line), fmt, ap);
    va_end(ap);
    if (n < 0)
        return;
    if (n > (int)sizeof(line))
        n = (int)sizeof(line);

    isotp_lock();
    (void)isotp_send(&g_link, (const uint8_t*)line, (uint16_t)n);
    isotp_unlock();
}


void can_isotp_init()
{
    /* Initialize link, 0xC8 is the CAN ID you send with */
    isotp_init_link(&g_link, ISOTP_TX_ID,
                    gSendBuf, sizeof(gSendBuf),
                    gRcvBuf, sizeof(gRcvBuf));

    g_link.send_arbitration_id    = ISOTP_TX_ID;  /* AWRL6844 -> PC */
    g_link.receive_arbitration_id = ISOTP_RX_ID;   /* PC -> AWRL6844 */

    /* Enable CAN FD, 64B data length, data-rate switching */
    isotp_config_can_fd(&g_link, 1 /*enable*/, 64 /*tx_dl*/, 1 /*brs*/);

    isotp_config_padding(&g_link, 1 /*enable*/, 0x00);

    /* As a receiver, advertise FC Block Size = 0 (no further FC frames) */
    isotp_config_receiver_bs(&g_link, 0);

    gIsoTpMutex = xSemaphoreCreateMutexStatic(&gIsoTpMutexBuf);

    gIsoTpPollTaskHandle = xTaskCreateStatic(
        IsoTpPollTask,
        "isotp_poll",
        ISOTP_POLL_STACK_DEPTH,
        NULL,
        ISOTP_POLL_TASK_PRIO,
        gIsoTpPollTaskStack,
        &gIsoTpPollTaskObj
    );
    configASSERT(gIsoTpPollTaskHandle != NULL);
}

void can_iso_tp_receive_mgr(uint32_t can_id, const uint8_t *data, uint8_t len)
{
    if (can_id != ISOTP_RX_ID) {
        printf("[can_iso_tp_receive_mgr] can_id=0x%02X\n", can_id);
        return;
    }
    if (len > RX_ISOTP_BUF_SIZE) {
        printf("[can_iso_tp_receive_mgr] len=%u\n", len);
        return;
    }

    uint32_t isotp_length;
    
#if 0
    if (len >= 3) {
        uint8_t pci_type = (data[0] >> 4) & 0x0F;
        if (pci_type == 0x3) { // FC
            uint8_t fs = (data[0] & 0x0F);
            uint8_t bs = data[1];
            uint8_t st = data[2];
            printf("[can_iso_tp_receive_mgr] FC recv: FS=%u (0=CTS), BS=%u, STmin=0x%02X\n", fs, bs, st);
        }
    }
#endif
    isotp_lock();
    //hexdump("can_iso_tp_receive_mgr", data, 64);
    isotp_on_can_message(&g_link, data, len);
    // When FC is received, send_status is changed internally to 1 (SENDING).
    uint8_t st = g_link.send_status;
    // uint8_t bs = g_link.send_bs_remain;
    // uint32_t off = g_link.send_offset;
    // uint32_t sz = g_link.send_size;
    isotp_unlock();

#if 0
    if (st == 2u) { // WAIT_FC
        printf("[ISO-TP] TX state: WAIT_FC (off=%lu/%lu)\n", (unsigned long)off, (unsigned long)sz);
    } else if (st == 1u) { // SENDING
        printf("[ISO-TP] TX state: SENDING (BS=%u, off=%lu/%lu)\n", bs, (unsigned long)off, (unsigned long)sz);
    } else { // idle
        printf("[ISO-TP] TX state: IDLE\n");
    }
#endif
    // --- Poll immediately after receiving FC and send CF immediately
    if (st == 1u) {
        isotp_lock();
        isotp_poll(&g_link);   // CF 1 is sent immediately
        isotp_unlock();
    }

    isotp_lock();
    int ret = isotp_receive(&g_link, rx_buf_isotp, RX_ISOTP_BUF_SIZE, &isotp_length);
    isotp_unlock();

    if (ISOTP_RET_OK == ret) {
        can_isotp_send_ack("OK\r\n");
        rx_buf_isotp[isotp_length] = '\0';
        //hexdump("ISO_TP Receive Data", rx_buf_isotp, isotp_length);
        can_rcv_message_handling(rx_buf_isotp, isotp_length);
        memset(rx_buf_isotp, 0, RX_ISOTP_BUF_SIZE);
    }
}

int32_t can_isotp_send_none_blocking(uint32_t msg_id, const uint8_t* data, int32_t size)
{
    if (!data || size <= 0) return 0;

    uint32_t now = isotp_user_get_ms();
    uint8_t st = get_send_status_locked();

    if (st != 0u) {
        if (gTxBusySinceMs == 0u)
            gTxBusySinceMs = now;

        if ((now - gTxBusySinceMs) <= TX_BUSY_RESET_MS) {
            isotp_lock(); isotp_poll(&g_link); isotp_unlock();
            return -1;
        }

        isotp_lock();
        force_full_idle_locked();
        isotp_unlock();
        gTxBusySinceMs = 0u;
    } else {
        gTxBusySinceMs = 0u;
    }

    isotp_lock();
    tx_buf_isotp[0] = (uint8_t)msg_id;
    memcpy(&tx_buf_isotp[1], data, size);
    int r = isotp_send(&g_link, (uint8_t*)tx_buf_isotp, (uint16_t)size+1);
    //memset(tx_buf_isotp, 0, TX_ISOTP_BUF_SIZE + 1u);
    isotp_unlock();

    return r;
}

int32_t can_isotp_send_blocking(uint32_t msg_id, const uint8_t* data, int32_t size)
{
    if (!data || size <= 0) return 0;

    uint32_t t0 = isotp_user_get_ms();
    for (;;) {
        uint8_t st = get_send_status_locked();
        if (st == 0u) break;

        isotp_lock(); isotp_poll(&g_link); isotp_unlock();

        if ((isotp_user_get_ms() - t0) > TX_BUSY_RESET_MS) {
            isotp_lock();
            force_full_idle_locked();
            isotp_unlock();
            break;
        }
        vTaskDelay(pdMS_TO_TICKS(1));
    }

    isotp_lock();
    tx_buf_isotp[0] = (uint8_t)msg_id;
    memcpy(&tx_buf_isotp[1], data, size);
    int r = isotp_send(&g_link, (uint8_t*)tx_buf_isotp, (uint16_t)size+1);
    //memset(tx_buf_isotp, 0, TX_ISOTP_BUF_SIZE + 1u);
    isotp_unlock();

    if (r < 0)
        return r;

    uint32_t deadline = isotp_user_get_ms() + 300u;
    for (;;) {
        uint8_t st = get_send_status_locked();
        if (st == 0u) break;
        if ((int32_t)(deadline - isotp_user_get_ms()) <= 0) break;

        isotp_lock(); isotp_poll(&g_link); isotp_unlock();
        vTaskDelay(pdMS_TO_TICKS(1));
    }
    return 0;
}

