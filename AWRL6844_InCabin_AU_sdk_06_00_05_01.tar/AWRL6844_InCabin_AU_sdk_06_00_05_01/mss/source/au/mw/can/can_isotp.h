#ifndef CAN_ISOTP_H
#define CAN_ISOTP_H

#include <stdint.h>

void can_isotp_init();
void can_iso_tp_receive_mgr(uint32_t can_id, const uint8_t *data, uint8_t len);
int32_t can_isotp_send_none_blocking(uint32_t msg_id, const uint8_t* data, int32_t size);
int32_t can_isotp_send_blocking(uint32_t msg_id, const uint8_t* data, int32_t size);

#endif /* CAN_ISOTP_H */
