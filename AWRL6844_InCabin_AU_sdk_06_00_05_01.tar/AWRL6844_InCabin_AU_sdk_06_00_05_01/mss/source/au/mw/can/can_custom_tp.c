/*
 * Copyright (C) 2025 AU Inc.
 *
 * Author   : AU
 * Desc     : The CAN mw acts as a bridge between the application layer and the driver hal layer.
 */

 #include <stdio.h>
#include <string.h>

#include "FreeRTOS.h"
#include "semphr.h"

#include "hal/can_hal.h"
#include "mw/can_mw.h"
#include "com/hexdump.h"
#include "app/rcv_message_process.h"
#include "mw/can/can_custom_tp.h"


#define RX_BUF_SIZE     4096u
#define TX_BUF_SIZE     16 * 1024u

#define TP_TX_ID  0xC8u  /* AWRL6844 -> PC */
#define TP_RX_ID  0xC0u  /* PC -> AWRL6844 */

#define CHUNK_LENGTH   63u
#define HDR_PBF_MASK   0x80u  /* 1=LAST, 0=MIDDLE */
#define HDR_VAL_MASK   0x7Fu  /* MIDDLE: seq, LAST: last_len */

#define CAN_HAL_SEND_FRAME_TIMEOUT_MS   20u   /* Maximum waits per frame */
#define CAN_HAL_SEND_RETRY_SLEEP_MS      1u   /* Retry interval */

typedef struct {
    uint8_t  buf[RX_BUF_SIZE];
    uint32_t len;
    uint8_t  seq_expect; /* 0..127 */
} rx_state_t;

static rx_state_t g_rx = {0};
static uint8_t  tx_buf[TX_BUF_SIZE];

static SemaphoreHandle_t gTpMutex;
static StaticSemaphore_t gTpMutexBuf;


static inline void rx_reset_inline(void)
{
    g_rx.seq_expect = 0u;
    g_rx.len = 0u;
    memset(g_rx.buf, 0, RX_BUF_SIZE);
}

static inline void tp_lock(void)
{
    xSemaphoreTake(gTpMutex, portMAX_DELAY);
}

static inline void tp_unlock(void)
{
    xSemaphoreGive(gTpMutex);
}

static int32_t send_frame_blocking(const uint8_t *frame, int32_t len) {
    uint32_t deadline = isotp_user_get_ms() + CAN_HAL_SEND_FRAME_TIMEOUT_MS;
    int32_t rc;
    do {
        rc = can_hal_send(TP_TX_ID, (uint8_t*)frame, len);
        if (rc >= 0) return rc;
        vTaskDelay(pdMS_TO_TICKS(CAN_HAL_SEND_RETRY_SLEEP_MS));
    } while ((int32_t)(deadline - isotp_user_get_ms()) > 0);
    return rc;
}

static int32_t custom_tp_send_data(uint8_t* data, int32_t size)
{
    if (data == NULL || size <= 0) return 0;

    uint8_t frame[1 + CHUNK_LENGTH]; /* 64B: [HDR][63] */
    int32_t pos = 0;
    uint8_t seq = 0;
    int32_t total_payload_sent = 0;

    /* MIDDLE frames: Transmitted in 63B units */
    while ((size - pos) > (int32_t)CHUNK_LENGTH) {
        frame[0] = (uint8_t)(seq & 0x7Fu);               /* bit7=0, seq */
        memcpy(&frame[1], &data[pos], CHUNK_LENGTH);

        int32_t rc = send_frame_blocking(frame, (int32_t)(1 + CHUNK_LENGTH));
        if (rc < 0) return rc;

        pos += (int32_t)CHUNK_LENGTH;
        total_payload_sent += (int32_t)CHUNK_LENGTH;
        seq = (uint8_t)((seq + 1u) & 0x7Fu);
    }

    /* LAST frame */
    int32_t remain = size - pos;
    uint8_t last_len;
    if (remain <= 0) {
        /* Length is a multiple of 63 → last_len=1..63 is required by the specification → 1-byte padding */
        last_len = 1u;
        frame[0] = (uint8_t)(0x80u | last_len);
        frame[1] = 0x00u;
        if (CHUNK_LENGTH > 1u) {
            memset(&frame[2], 0x00, (size_t)(CHUNK_LENGTH - 1u));
        }
    } else {
        if (remain > (int32_t)CHUNK_LENGTH) remain = (int32_t)CHUNK_LENGTH;
        last_len = (uint8_t)remain;

        frame[0] = (uint8_t)(0x80u | (last_len & HDR_VAL_MASK)); /* bit7=1 */
        memcpy(&frame[1], &data[pos], (size_t)last_len);
        if (last_len < CHUNK_LENGTH) {
            memset(&frame[1 + last_len], 0x00, (size_t)(CHUNK_LENGTH - last_len));
        }
        total_payload_sent += (int32_t)last_len;
    }

    int32_t rc = send_frame_blocking(frame, (int32_t)(1 + CHUNK_LENGTH));
    if (rc < 0) return rc;

    return total_payload_sent; /* Actual number of payload bytes (excluding padding) */
}


void can_custom_tp_init(void)
{
    gTpMutex = xSemaphoreCreateMutexStatic(&gTpMutexBuf);
}

int32_t can_custom_tp_send(uint32_t msg_id, uint8_t* data, int32_t size)
{
    if (!data || size <= 0) return 0;
    if ((size + 1) > (int32_t)(sizeof(tx_buf))) return -1;

    tp_lock();
    tx_buf[0] = (uint8_t)msg_id;
    memcpy(&tx_buf[1], data, (size_t)size);
    int rc = custom_tp_send_data(tx_buf, size + 1);
    tp_unlock();
    return rc;
}

void can_custom_tp_receive_mgr(const uint8_t *data)
{
/* Wire format: [HDR][PAYLOAD<=63]
   - HDR bit7 : 1 = LAST, 0 = MIDDLE
   - HDR bit6..0 : MIDDLE→SEQ(0..127), LAST→last_len(1..63) */

    const uint8_t  hdr     = data[0];
    const uint8_t  is_last = (hdr & HDR_PBF_MASK) ? 1u : 0u;
    const uint8_t  val     = (hdr & HDR_VAL_MASK);
    const uint8_t *payload = &data[1];

    if (!is_last) {
        /* Middle: val == seq_no */
        if (val != g_rx.seq_expect) {
            printf("SeqErr: expect %u, got %u\n", g_rx.seq_expect, val);
            rx_reset_inline();
            return;
        }
        if ((g_rx.len + CHUNK_LENGTH) > RX_BUF_SIZE) {
            printf("Overflow: len=%lu\n", (unsigned long)g_rx.len);
            rx_reset_inline();
            return;
        }
        memcpy(g_rx.buf + g_rx.len, payload, CHUNK_LENGTH);
        g_rx.len += CHUNK_LENGTH;
        g_rx.seq_expect = (uint8_t)((g_rx.seq_expect + 1u) & 0x7Fu);
    } else {
        /* Last: val == last_len (1..63) */
        const uint8_t last_len = val;
        if ((last_len == 0u) || (last_len > CHUNK_LENGTH)) {
            rx_reset_inline();
            return;
        }
        if ((g_rx.len + last_len) > RX_BUF_SIZE) {
            rx_reset_inline();
            return;
        }
        memcpy(g_rx.buf + g_rx.len, payload, last_len);
        g_rx.len += last_len;
        g_rx.buf[g_rx.len] = '\0';

        //hexdump("rcv_custom", (const uint8_t*)g_rx.buf, g_rx.len);
        can_rcv_message_handling(g_rx.buf, g_rx.len);
        rx_reset_inline();
    }
}

