#ifndef CAN_CUSTOM_TP_H
#define CAN_CUSTOM_TP_H

#include <stdint.h>

void can_custom_tp_init(void);
void can_custom_tp_receive_mgr(const uint8_t *data);
int32_t can_custom_tp_send(uint32_t msg_id, uint8_t* data, int32_t size);

#endif /* CAN_CUSTOM_TP_H */
