/*
 * Copyright (C) 2025 AU Inc.
 *
 * Author   : AU
 * Desc     : The CAN mw acts as a bridge between the application layer and the driver hal layer.
 *
 */

#ifndef _CAN_MW_H_
#define _CAN_MW_H_

#include <stdint.h>

void can_driver_init(void);

int32_t can_send_data(uint32_t msg_id, uint8_t* data, int32_t size);
int32_t can_send_message(uint32_t msg_id, uint8_t* data, int32_t size);

#endif
