#ifndef RCV_MESSAGE_PROCESS_H
#define RCV_MESSAGE_PROCESS_H

#include <stdint.h>

void can_rcv_message_handling(const uint8_t* data, int32_t size);

#endif /* RCV_MESSAGE_PROCESS_H */
