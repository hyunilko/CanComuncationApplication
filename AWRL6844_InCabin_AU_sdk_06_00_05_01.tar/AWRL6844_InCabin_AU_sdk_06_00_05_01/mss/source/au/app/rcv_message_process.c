#include <stdio.h>
#include <string.h>

#include "source/mmw_cli.h"
#include "app/message_id_define.h"
#include "app/rcv_message_process.h"
#include "com/hexdump.h"
#include "com/conversion.h"

#define PROFILE_COMCFG_WIRE_SIZE    11

#pragma pack(push, 1)
typedef struct ProfileComCfg_t {
    uint8_t  digOutputSampRate;
    uint8_t  digOutputBitsSel;
    uint8_t  dfeFirSel;
    uint16_t numOfAdcSamples;
    float    chirpRampEndTimeus;
    uint8_t  chirpRxHpfSel;
    uint8_t  chirpTxMimoPatSel;
} ProfileComCfg;
#pragma pack(pop)
_Static_assert(sizeof(ProfileComCfg) == PROFILE_COMCFG_WIRE_SIZE, "ProfileComCfg must be 11 bytes (packed)");

static bool parse_ProfileComCfg(ProfileComCfg *out, const uint8_t *p, int32_t n)
{
    if (!out || !p || n < PROFILE_COMCFG_WIRE_SIZE) return false;

    out->digOutputSampRate = p[0];
    out->digOutputBitsSel  = p[1];
    out->dfeFirSel         = p[2];
    out->numOfAdcSamples   = little_endian_to_uint16(&p[3]);

    //memcpy(&out->chirpRampEndTimeus, p + 5, sizeof(float));
    out->chirpRampEndTimeus = little_endian_to_float(&p[5]);
    out->chirpRxHpfSel     = p[9];
    out->chirpTxMimoPatSel = p[10];
    return true;
}

static void process_profile_config(const ProfileComCfg *cfg){
    if (!cfg) return;

    printf("cmd> process_profile_config %u, %u, %u, %u, %.3f, %u, %u\n",
        (unsigned)cfg->digOutputSampRate,
        (unsigned)cfg->digOutputBitsSel,
        (unsigned)cfg->dfeFirSel,
        (unsigned)cfg->numOfAdcSamples,
        cfg->chirpRampEndTimeus,
        (unsigned)cfg->chirpRxHpfSel,
        (unsigned)cfg->chirpTxMimoPatSel
    );
    printf ("Done\n");
    fflush(stdout);
}

void can_rcv_message_handling(const uint8_t* data, int32_t size)
{
    if (!data || size < 1) return;

    uint8_t msg_id = data[0];
    int32_t pdu_size = size - 1;

    //printf("can_rcv_message_handling msg_id:0x%02X\n", msg_id);
    //hexdump("can_rcv_message_handling", data, size);

    switch (msg_id) {
    case CAN_MESSAGE_CLI:
        CLI_executeCommand((const char *)&data[1]);
        break;

    case CAN_MESSAGE_PROFILE_CONFIG:
    {
        if (pdu_size < PROFILE_COMCFG_WIRE_SIZE) {
            printf("PROFILE_CONFIG too short: %ld\n", (long)pdu_size);
            break;
        }
        ProfileComCfg cfg;
        if (!parse_ProfileComCfg(&cfg, &data[1], pdu_size)) {
            printf("PROFILE_CONFIG parse failed\n");
            break;
        }
        process_profile_config(&cfg);
        // process_profile_config((ProfileComCfg *)&data[1]);
        break;
    }

    default:
        printf("can_rcv_message_handling not defined msg_id:0x%02X\n", msg_id);
        break;
    }
}
