#ifndef MESSAGE_DEFINE_H
#define MESSAGE_DEFINE_H

typedef enum can_message_type_e
{
    CAN_MESSAGE_PROFILE_CONFIG = 0x24,

    /*! @brief   List of detected points */
    CAN_MESSAGE_DETECTED_POINTS = 0x64,

    /*! @brief   Range profile */
    CAN_MESSAGE_RANGE_PROFILE,
	
    /*! @brief   Noise floor profile */
    CAN_MESSAGE_NOISE_PROFILE,

    /*! @brief   Samples to calculate static azimuth  heatmap */
    CAN_MESSAGE_AZIMUT_STATIC_HEAT_MAP,

    /*! @brief   Range/Doppler detection matrix */
    CAN_MESSAGE_RANGE_DOPPLER_HEAT_MAP,

    /*! @brief   Stats information */
    CAN_MESSAGE_STATS,

    /*! @brief   Side information */
    CAN_MESSAGE_SIDE_INFO,
	
	/* Send Rx Channel compensation coefficients */
    CAN_MESSAGE_RX_CHANNEL_COMPENSATION_COEFFICIENTS,

    CAN_MESSAGE_OCCUPANCY_FEATURES,
    CAN_MESSAGE_HEIGHT_ESTIMATION,
    CAN_MESSAGE_CLASSIFICATION_RESULT,
    CAN_MESSAGE_INTRUSION_DETECTION,
    CAN_MESSAGE_INTRUSION_DET_3D_DET_MAT,
    CAN_MESSAGE_INTRUSION_DET_3D_SNR,
    CAN_MESSAGE_ANTENNA_GEOMETRY,
    CAN_MESSAGE_DET_MAT_ANGLE_SLICE,
    CAN_MESSAGE_SNR_MAT_ANGLE_SLICE,
    CAN_MESSAGE_CAPON_HEATMAP,
    CAN_MESSAGE_COARSE_POINT_CLOUD,
    CAN_MESSAGE_RADAR_CUBE_CHUNK,

    CAN_MESSAGE_CLI = 0xFA,
} can_message_type;


#endif

