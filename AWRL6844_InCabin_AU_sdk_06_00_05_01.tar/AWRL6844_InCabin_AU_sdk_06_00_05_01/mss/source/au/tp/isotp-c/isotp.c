/*
 * ISO 15765-2 (ISO-TP) over CAN / CAN FD
 *  - Classical (8B) + CAN FD (up to 64B) support
 *  - FD-SF extended length, FF 12-bit length, CF fixed payload size by FF frame len
 *  - STmin (ms and 0xF1..0xF9 = 100..900us) handling
 *
 * Compatible with SimonCahill/isotp-c public API (extended).
 * License: MIT
 */

#include <string.h>
#include <stdint.h>
#include "isotp.h"

/* ===== External hooks provided by platform ===== */
extern int      isotp_user_send_can(uint32_t arbitration_id, const uint8_t *data, uint8_t len);
extern uint32_t isotp_user_get_ms(void);
extern void     isotp_user_debug(const char* fmt, ...);

/* ===== Return codes (fallbacks if not defined in header) ===== */
#ifndef ISOTP_RET_OK
#define ISOTP_RET_OK          (0)
#endif
#ifndef ISOTP_RET_NO_DATA
#define ISOTP_RET_NO_DATA     (-1)
#endif
#ifndef ISOTP_RET_OVERFLOW
#define ISOTP_RET_OVERFLOW    (-2)
#endif
#ifndef ISOTP_RET_ERROR
#define ISOTP_RET_ERROR       (-3)
#endif
#ifndef ISOTP_RET_TIMEOUT
#define ISOTP_RET_TIMEOUT     (-4)
#endif
#ifndef ISOTP_RET_AGAIN
#define ISOTP_RET_AGAIN       (-11)
#endif

/* ===== Defaults / Tunables ===== */
#ifndef ISOTP_DEFAULT_CANFD_DL
#define ISOTP_DEFAULT_CANFD_DL      64u
#endif
#ifndef ISOTP_DEFAULT_PADDING
#define ISOTP_DEFAULT_PADDING       0x00u
#endif
#ifndef ISOTP_TX_STALL_TIMEOUT_MS
#define ISOTP_TX_STALL_TIMEOUT_MS   1500u
#endif
#ifndef ISOTP_WFTMAX
#define ISOTP_WFTMAX                8u
#endif

/* PCI types */
#define PCI_TYPE_SF  0x0u
#define PCI_TYPE_FF  0x1u
#define PCI_TYPE_CF  0x2u
#define PCI_TYPE_FC  0x3u

/* FlowStatus */
#define FC_STATUS_CTS     0x0u
#define FC_STATUS_WAIT    0x1u
#define FC_STATUS_OVFLW   0x2u

/* send_status 확장 값 */
#define ISOTP_SEND_IDLE      0u
#define ISOTP_SEND_SENDING   1u
#define ISOTP_SEND_WAIT_FC   2u
#define ISOTP_SEND_WAIT_HW   4u

/* Return helpers */
#ifndef MIN2
#define MIN2(a,b) (( (a) < (b) ) ? (a) : (b))
#endif

/* DLC→Length (FD). If driver already gives real 'len', this is unused. */
static inline uint8_t can_dlc_to_len(uint8_t dlc) {
    static const uint8_t map[16] = {
        0,1,2,3,4,5,6,7, 8,12,16,20,24,32,48,64
    };
    return map[dlc & 0x0Fu];
}

/* STmin decode to microseconds */
static inline uint32_t stmin_to_us(uint8_t st) {
    if (st <= 0x7F)   return (uint32_t)st * 1000u;
    if (st >= 0xF1 && st <= 0xF9) return (uint32_t)(st - 0xF0) * 100u;
    return 0u;
}

static inline uint8_t addr_off(const IsoTpLink *link) {
    return link->ext_addr ? 1u : 0u;
}

/* Effective TX/RX frame data length */
static inline uint8_t eff_dl_tx(const IsoTpLink *link) {
    if (!link->can_fd) return 8u;
    return link->tx_dl ? link->tx_dl : ISOTP_DEFAULT_CANFD_DL;
}
static inline uint8_t eff_dl_rx(const IsoTpLink *link, uint8_t recv_len_fallback) {
    if (!link->can_fd) return 8u;
    return link->rx_dl ? link->rx_dl : recv_len_fallback;
}

/* Payload capacity per SF/CF */
static inline uint8_t sf_payload_cap(uint8_t dl, uint8_t aoff, uint8_t can_fd) {
    if (!can_fd || dl <= 8u) {
        if (dl <= (uint8_t)(aoff + 1u)) return 0u;
        return (uint8_t)(dl - (aoff + 1u));
    } else {
        if (dl <= (uint8_t)(aoff + 2u)) return 0u;
        return (uint8_t)(dl - (aoff + 2u));
    }
}
static inline uint8_t cf_payload_cap(uint8_t dl, uint8_t aoff) {
    if (dl <= (uint8_t)(aoff + 1u)) return 0u;
    return (uint8_t)(dl - (aoff + 1u));
}

static int isotp_send_frame(IsoTpLink *link, uint8_t *frame, uint8_t used, uint8_t target_dl) {
#if defined(ISO_TP_FRAME_PADDING)
    uint8_t do_pad = 1u;
#else
    uint8_t do_pad = link->padding_enable ? 1u : 0u;
#endif
    if (do_pad) {
        while (used < target_dl) {
            frame[used++] = link->padding_value;
        }
    }
    int rc = isotp_user_send_can(link->send_arbitration_id, frame, used);
    if (rc == -11 /*EAGAIN*/ || rc == ISOTP_RET_AGAIN) return ISOTP_RET_AGAIN;
    return (rc < 0) ? ISOTP_RET_ERROR : ISOTP_RET_OK;
}

/* Send FlowControl */
static void isotp_send_flow_control(IsoTpLink *link, uint8_t fs, uint8_t bs, uint8_t stmin) {
    uint8_t frame[64];
    uint8_t i = 0;
    const uint8_t aoff = addr_off(link);
    const uint8_t dl   = eff_dl_tx(link);

    if (aoff) frame[i++] = 0x00; /* ext addr value if used */
    frame[i++] = (uint8_t)((PCI_TYPE_FC << 4) | (fs & 0x0F));
    frame[i++] = bs;
    frame[i++] = stmin;

    (void)isotp_send_frame(link, frame, i, dl);
}

/* ===== Public API ===== */

void isotp_init_link(IsoTpLink *link, uint32_t sendid,
                     uint8_t *sendbuf, uint32_t sendbufsize,
                     uint8_t *recvbuf, uint32_t recvbufsize)
{
    memset(link, 0, sizeof(*link));

    link->send_arbitration_id = sendid;

    /* Buffers */
    link->send_buffer      = sendbuf;
    link->send_buf_size    = sendbufsize;
    link->receive_buffer   = recvbuf;
    link->receive_buf_size = recvbufsize;

    /* TX defaults */
    link->send_size            = 0u;
    link->send_offset          = 0u;
    link->send_sn              = 0u;
    link->send_bs_remain       = 0u;
    link->send_st_min_us       = 0u;
    link->send_wtf_count       = 0u;
    link->send_timer_st        = 0u;
    link->send_timer_bs        = 0u;
    link->send_protocol_result = 0;
    link->send_status          = ISOTP_SEND_IDLE;

    /* RX defaults */
    link->receive_size            = 0u;
    link->receive_offset          = 0u;
    link->receive_sn              = 1u; /* first expected SN after FF is 1 */
    link->receive_bs_count        = 8u; /* default advertised BS (tune as needed) */
    link->receive_timer_cr        = 0u;
    link->receive_protocol_result = 0;
    link->receive_status          = 0u; /* idle */

    /* CAN FD ext */
    link->can_fd         = 0u;           /* classical default */
    link->tx_dl          = 8u;
    link->rx_dl          = 0u;
    link->padding_enable = 0u;
    link->padding_value  = ISOTP_DEFAULT_PADDING;
    link->ext_addr       = 0u;
    link->brs            = 0u;
}

void isotp_config_can_fd(IsoTpLink *link, uint8_t enable, uint8_t tx_dl, uint8_t brs) {
    link->can_fd = enable ? 1u : 0u;
    link->tx_dl  = enable ? (tx_dl ? tx_dl : ISOTP_DEFAULT_CANFD_DL) : 8u;
    link->brs    = enable ? (brs ? 1u : 0u) : 0u;
}

void isotp_config_padding(IsoTpLink *link, uint8_t enable, uint8_t pad) {
    link->padding_enable = enable ? 1u : 0u;
    link->padding_value  = pad;
}

void isotp_config_receiver_bs(IsoTpLink *link, uint8_t bs) {
    link->receive_bs_count = bs; /* 0=infinite */
}

/* Receive one CAN frame */
void isotp_on_can_message(IsoTpLink *link, const uint8_t *data, uint8_t len) {
    if (len < 2u) return;                 /* need at least PCI */
    if (!link->can_fd && len > 8u)  return;
    if (link->can_fd && len > 64u)  return;

    const uint8_t aoff = addr_off(link);
    if (len <= aoff) return;

    const uint8_t *p = data + aoff;
    uint8_t pci  = p[0];
    uint8_t type = (uint8_t)((pci >> 4) & 0x0F);

    switch (type) {
    case PCI_TYPE_SF: {
        /* SF: Classical -> nibble len; FD(len>8) -> nibble==0 then p[1]=SF_DL */
        uint16_t sf_len = (uint16_t)(pci & 0x0F);
        uint8_t  pay_off = 1u;

        if (link->can_fd && len > 8u) {
            if (sf_len != 0u || len < (uint8_t)(aoff + 2u)) return;
            sf_len = p[1];
            pay_off = 2u;
        }
        if ((uint32_t)(aoff + pay_off + sf_len) > (uint32_t)len) return;

        if (sf_len > link->receive_buf_size) {
            link->receive_protocol_result = ISOTP_RET_OVERFLOW;
            return;
        }
        memcpy(link->receive_buffer, p + pay_off, sf_len);
        link->receive_size   = sf_len;
        link->receive_offset = sf_len;
        link->receive_status = 2u; /* completed */
        break;
    }

    case PCI_TYPE_FF: {
        /* 12-bit length: ((pci&0xF)<<8) | p[1] */
        uint16_t ff_len_12 = (uint16_t)(((uint16_t)(pci & 0x0F) << 8) | p[1]);
        uint32_t total_len = ff_len_12;
        uint8_t  pay_off   = 2u;
        if (total_len == 0u) return;

        /* Fix rx_dl for this session to the FF frame length */
        link->rx_dl = len;

        /* Prepare RX state */
        link->receive_status    = 1u; /* in progress */
        link->receive_size      = total_len;
        link->receive_offset    = 0u;
        link->receive_sn        = 1u;
        link->receive_protocol_result = 0;

        /* Copy what’s inside FF after PCI */
        uint16_t remain_in_ff = 0u;
        if (len > (uint8_t)(aoff + pay_off)) {
            remain_in_ff = (uint16_t)((uint16_t)len - (uint16_t)(aoff + pay_off));
        }
        uint16_t will_copy = (uint16_t)MIN2(remain_in_ff, (uint16_t)total_len);
        if (will_copy > link->receive_buf_size) {
            link->receive_protocol_result = ISOTP_RET_OVERFLOW;
            return;
        }
        memcpy(link->receive_buffer, p + pay_off, will_copy);
        link->receive_offset = will_copy;

        /* Advertise FC(CTS) with our BS and STmin=0 (ASAP) */
        isotp_send_flow_control(link, FC_STATUS_CTS,
                                link->receive_bs_count, /* BS */
                                0 /* STmin */);
        break;
    }

    case PCI_TYPE_CF: {
        if (link->receive_status != 1u) return; /* not in progress */

        uint8_t sn = (uint8_t)(pci & 0x0F);
        if (sn != link->receive_sn) {
            /* SN error -> drop sequence (simple behavior) */
            return;
        }

        uint16_t payload_len = 0u;
        if (len > (uint8_t)(aoff + 1u)) {
            payload_len = (uint16_t)((uint16_t)len - (uint16_t)(aoff + 1u));
        }

        uint32_t remain = (link->receive_size > link->receive_offset)
                        ? (link->receive_size - link->receive_offset) : 0u;
        uint16_t to_copy = (uint16_t)MIN2(remain, (uint32_t)payload_len);

        if ((link->receive_offset + to_copy) > link->receive_buf_size) {
            link->receive_protocol_result = ISOTP_RET_OVERFLOW;
            return;
        }

        memcpy(&link->receive_buffer[link->receive_offset], p + 1, to_copy);
        link->receive_offset += to_copy;

        if (link->receive_offset >= link->receive_size) {
            link->receive_status = 2u; /* completed */
        } else {
            /* If BS!=0 we could send FC periodically; keep simple here. */
        }

        link->receive_sn = (uint8_t)((link->receive_sn + 1u) & 0x0Fu);
        break;
    }

    case PCI_TYPE_FC: {
        /* FC from peer (we are sender) */
        if (link->send_status != ISOTP_SEND_WAIT_FC && link->send_status != ISOTP_SEND_SENDING) {
            return;
        }
        uint8_t fs = (uint8_t)(pci & 0x0F);
        uint8_t bs = p[1];
        uint8_t st = p[2];

        if (fs == FC_STATUS_CTS) {
            link->send_bs_remain = (bs == 0u) ? 0xFFu : bs;
            link->send_st_min_us = stmin_to_us(st);
            link->send_status    = ISOTP_SEND_SENDING;
            link->send_timer_st  = isotp_user_get_ms();
            link->send_timer_bs  = link->send_timer_st;
            link->send_wtf_count = 0u;
        } else if (fs == FC_STATUS_WAIT) {
            if (++link->send_wtf_count > ISOTP_WFTMAX) {
                link->send_status = ISOTP_SEND_IDLE;   /* abort */
                link->send_protocol_result = ISOTP_RET_TIMEOUT;
            } else {
                /* Simple: push next try a little later */
                link->send_timer_st  = isotp_user_get_ms() + 5u;
            }
        } else { /* OVFLW */
            link->send_status = ISOTP_SEND_IDLE; /* abort */
            link->send_protocol_result = ISOTP_RET_ERROR;
        }
        break;
    }

    default:
        /* ignore unknown */
        break;
    }
}

/* App pulls reassembled PDU */
int isotp_receive(IsoTpLink *link, uint8_t *payload, const uint32_t payload_size, uint32_t *out_size) {
    if (link->receive_status != 2u) return ISOTP_RET_NO_DATA;
    if (link->receive_size > payload_size) return ISOTP_RET_OVERFLOW;

    memcpy(payload, link->receive_buffer, link->receive_size);
    *out_size = link->receive_size;

    /* Reset RX state */
    link->receive_status = 0u;
    link->receive_size   = 0u;
    link->receive_offset = 0u;
    link->receive_sn     = 1u;
    return ISOTP_RET_OK;
}

/* TX: start sending a PDU */
int isotp_send(IsoTpLink *link, const uint8_t payload[], uint32_t size) {
    if (size == 0u) return ISOTP_RET_ERROR;
    if (link->send_status != ISOTP_SEND_IDLE) return ISOTP_RET_INPROGRESS;

    const uint8_t aoff = addr_off(link);
    const uint8_t dl   = eff_dl_tx(link);
    uint8_t frame[64];
    uint8_t i = 0;

    /* Single Frame? */
    const uint8_t sf_cap = sf_payload_cap(dl, aoff, link->can_fd);
    if (size <= sf_cap) {
        if (aoff) frame[i++] = 0x00;
        if (!link->can_fd || dl <= 8u) {
            frame[i++] = (uint8_t)((PCI_TYPE_SF << 4) | (uint8_t)size);
        } else {
            frame[i++] = (uint8_t)(PCI_TYPE_SF << 4);   /* low nibble 0 => extended length */
            frame[i++] = (uint8_t)size;                 /* SF_DL */
        }
        memcpy(&frame[i], payload, size);
        i = (uint8_t)(i + size);

        int rc = isotp_send_frame(link, frame, i, dl);
        if (rc == ISOTP_RET_AGAIN) {
            memcpy(link->send_buffer, payload, size);
            link->send_size      = size;
            link->send_offset    = size;
            link->send_sn        = 0u;
            link->send_status    = ISOTP_SEND_WAIT_HW;
            link->send_st_min_us = 1000u;
            link->send_timer_st  = isotp_user_get_ms() + 1u;
            return ISOTP_RET_OK;
        }
        return (rc < 0) ? ISOTP_RET_ERROR : ISOTP_RET_OK;
    }

    /* Multi-frame: copy payload into link->send_buffer */
    if (size > link->send_buf_size) return ISOTP_RET_OVERFLOW;
    memcpy(link->send_buffer, payload, size);

    /* First Frame (12-bit length) */
    if (aoff) frame[i++] = 0x00;
    if (size > 4095u) { /* compact implementation: up to 4095 */
        return ISOTP_RET_ERROR;
    }
    frame[i++] = (uint8_t)((PCI_TYPE_FF << 4) | (uint8_t)((size >> 8) & 0x0F));
    frame[i++] = (uint8_t)(size & 0xFF);

    uint8_t ff_pay = (dl > (uint8_t)(aoff + 2u)) ? (uint8_t)(dl - (aoff + 2u)) : 0u;
    uint16_t cpy = (uint16_t)MIN2((uint32_t)ff_pay, (uint32_t)size);
    memcpy(&frame[i], link->send_buffer, cpy);
    i = (uint8_t)(i + cpy);

    int ff_rc = isotp_send_frame(link, frame, i, dl);
    if (ff_rc == ISOTP_RET_AGAIN) {
        link->send_size      = size;
        link->send_offset    = 0u;
        link->send_sn        = 1u;
        link->send_status    = ISOTP_SEND_WAIT_HW;
        link->send_st_min_us = 1000u;
        link->send_timer_st  = isotp_user_get_ms() + 1u;
        return ISOTP_RET_OK;
    }
    if (ff_rc < 0) return ISOTP_RET_ERROR;

    /* Setup TX state (FF OK → WAIT_FC) */
    link->send_size      = size;
    link->send_offset    = cpy;
    link->send_sn        = 1u;
    link->send_status    = ISOTP_SEND_WAIT_FC;
    link->send_bs_remain = 0u;
    link->send_st_min_us = 0u;
    link->send_timer_st  = isotp_user_get_ms();
    link->send_timer_bs  = link->send_timer_st;
    link->send_wtf_count = 0u;
    return ISOTP_RET_OK;
}

/* Send next Consecutive Frame (CF).
   - send_bs_remain == 0xFFu  : peer BS=0 (Infinite allowance)
   - send_bs_remain == 0u     : Have to wait for the next FC (WAIT_FC)
*/
static int isotp_tx_send_next_cf(IsoTpLink *link) {
    const uint8_t dl   = eff_dl_tx(link);
    const uint8_t aoff = addr_off(link);
    uint8_t frame[64];
    uint8_t i = 0;

    /* If everything has already been sent, idle */
    if (link->send_offset >= link->send_size) {
        link->send_status = ISOTP_SEND_IDLE;
        return ISOTP_RET_OK;
    }

    /* If peer BS is exhausted, wait until the next FC (except infinite = 0xFF) */
    if (link->send_bs_remain != 0xFFu && link->send_bs_remain == 0u) {
        link->send_status = ISOTP_SEND_WAIT_FC;
        return ISOTP_RET_OK;
    }

    if (aoff) frame[i++] = 0x00;
    frame[i++] = (uint8_t)((PCI_TYPE_CF << 4) | (link->send_sn & 0x0Fu));

    const uint8_t  cap    = cf_payload_cap(dl, aoff);
    const uint32_t remain = link->send_size - link->send_offset;
    const uint16_t cpy    = (uint16_t)MIN2(remain, (uint32_t)cap);

    memcpy(&frame[i], &link->send_buffer[link->send_offset], cpy);
    i = (uint8_t)(i + cpy);

    int s_rc = isotp_send_frame(link, frame, i, dl);
    if (s_rc == ISOTP_RET_AGAIN) {
        /* Hardware busy → Retry in next poll (offset/SN increase prohibited) */
        link->send_timer_st = isotp_user_get_ms() + 1u;
        return ISOTP_RET_OK;
    }
    if (s_rc < 0) return ISOTP_RET_ERROR;

    /* Progress update */
    link->send_offset += cpy;
    link->send_sn = (uint8_t)((link->send_sn + 1u) & 0x0Fu);

    /* Decrease/wait processing only when there is a finite BS */
    if (link->send_bs_remain != 0xFFu) {
        if (link->send_bs_remain > 0u) {
            link->send_bs_remain--;
            if (link->send_bs_remain == 0u && link->send_offset < link->send_size) {
                link->send_status = ISOTP_SEND_WAIT_FC;
            }
        }
    }

    link->send_timer_bs = isotp_user_get_ms();

    /* If all data has been sent, switch to idle */
    if (link->send_offset >= link->send_size) {
        link->send_status = ISOTP_SEND_IDLE;
    }

    return ISOTP_RET_OK;
}


/* Poll: handle STmin pacing and continue CF transmissions + WAIT_HW retry + stall monitoring */
void isotp_poll(IsoTpLink *link) {
    uint32_t now = isotp_user_get_ms();

    /* Stall Watchdog: Determines overrun based on progress-related timestamps */
    if (link->send_status != ISOTP_SEND_IDLE) {
        uint32_t last = link->send_timer_bs ? link->send_timer_bs : link->send_timer_st;
        if (last && (now - last) > ISOTP_TX_STALL_TIMEOUT_MS) {
            link->send_status = ISOTP_SEND_IDLE;
            link->send_protocol_result = ISOTP_RET_TIMEOUT;
            link->send_offset = 0u;
            link->send_size   = 0u;
            link->send_sn     = 0u;
            link->send_bs_remain = 0u;
            link->send_timer_st = 0u;
            link->send_timer_bs = 0u;
            isotp_user_debug("[ISOTP] TX stall > %u ms → force-idle\n", (unsigned)ISOTP_TX_STALL_TIMEOUT_MS);
            return;
        }
    }

    /* FF/SF could not be sent due to hardware busy → Retry */
    if (link->send_status == ISOTP_SEND_WAIT_HW) {
        if (now >= link->send_timer_st) {
            const uint8_t aoff = addr_off(link);
            const uint8_t dl   = eff_dl_tx(link);
            uint8_t frame[64]; uint8_t i=0;

            if (link->send_offset == 0u) {
                /* FF resend */
                if (aoff) frame[i++] = 0x00;
                frame[i++] = (uint8_t)((PCI_TYPE_FF<<4) | (uint8_t)((link->send_size>>8)&0x0F));
                frame[i++] = (uint8_t)(link->send_size & 0xFF);
                uint8_t ff_pay = (dl > (uint8_t)(aoff + 2u)) ? (uint8_t)(dl - (aoff + 2u)) : 0u;
                uint16_t cpy = (uint16_t)MIN2((uint32_t)ff_pay, link->send_size);
                memcpy(&frame[i], link->send_buffer, cpy); i=(uint8_t)(i+cpy);
                int ff_rc = isotp_send_frame(link, frame, i, dl);
                if (ff_rc == ISOTP_RET_AGAIN) {
                    link->send_timer_st = now + 1u;
                    return;
                }
                if (ff_rc < 0) {
                    link->send_status = ISOTP_SEND_IDLE; /* abort */
                    link->send_protocol_result = ISOTP_RET_ERROR;
                    return;
                }
                link->send_offset = cpy;
                link->send_status = ISOTP_SEND_WAIT_FC;
                link->send_timer_st = now;
                link->send_timer_bs = now;
                link->send_wtf_count = 0u;
            } else {
                /* SF retry: separated send_offset==size */
                if (aoff) frame[i++] = 0x00;
                frame[i++] = (uint8_t)(PCI_TYPE_SF << 4);
                frame[i++] = (uint8_t)link->send_size;
                memcpy(&frame[i], link->send_buffer, link->send_size);
                i = (uint8_t)(i + link->send_size);
                int rc = isotp_send_frame(link, frame, i, dl);
                if (rc == ISOTP_RET_AGAIN) {
                    link->send_timer_st = now + 1u;
                    return;
                }
                link->send_status = (rc < 0) ? ISOTP_SEND_IDLE : ISOTP_SEND_IDLE;
                link->send_protocol_result = (rc < 0) ? ISOTP_RET_ERROR : ISOTP_RET_OK;
            }
        }
        return;
    }

    /* Existing SENDING/STmin processing */
    if (link->send_status == ISOTP_SEND_SENDING) {
        if (link->send_st_min_us == 0u) {
            (void)isotp_tx_send_next_cf(link);
        } else {
            /* coarse ms pacing */
            uint32_t due_ms = link->send_timer_st;
            if (now >= due_ms) {
                (void)isotp_tx_send_next_cf(link);
                /* next due */
                uint32_t delta_ms = (link->send_st_min_us + 999u) / 1000u; /* ceil us->ms */
                link->send_timer_st = isotp_user_get_ms() + delta_ms;
            }
        }
    }
}

/* Send with specific CAN ID (functional etc.) */
int isotp_send_with_id(IsoTpLink *link, uint32_t id, const uint8_t payload[], uint32_t size) {
    uint32_t old = link->send_arbitration_id;
    link->send_arbitration_id = id;
    int r = isotp_send(link, payload, size);
    link->send_arbitration_id = old;
    return r;
}
