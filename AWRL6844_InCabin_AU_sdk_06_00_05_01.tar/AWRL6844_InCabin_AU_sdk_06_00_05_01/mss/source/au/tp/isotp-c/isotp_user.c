#include <stdio.h>
#include <stdarg.h>
#include <kernel/dpl/ClockP.h>
#include "hal/can_hal.h"
#include "FreeRTOS.h"

/* required, this must send a single CAN message with the given arbitration
    * ID (i.e. the CAN message ID) and data. The size will never be more than 8
    * bytes. Should return ISOTP_RET_OK if frame sent successfully.
    * May return ISOTP_RET_NOSPACE if the frame could not be sent but may be
    * retried later. Should return ISOTP_RET_ERROR in case frame could not be sent.
    */
int  isotp_user_send_can(const uint32_t arbitration_id,
                            const uint8_t* data, const uint8_t size) {
    uint32_t id11 = (arbitration_id & 0x7FFu);
    int32_t rc = can_hal_send(id11, (uint8_t*)data, (int32_t)size);
    /* 0 = queued OK, -11 = EAGAIN (busy → retry after 1ms from the parent), otherwise hard error */
    if (rc == 0)      return 0;
    if (rc == -11)    return -11;   /* EAGAIN */
    return -1;
}

/* required, return system tick, unit is micro-second */
uint32_t isotp_user_get_us(void) {
    return ClockP_getTimeUsec();
}

/* required, return system tick, unit is mili-second */
uint32_t isotp_user_get_ms(void) {
    return (uint32_t)(xTaskGetTickCount() * portTICK_PERIOD_MS);
}

/* optional, provide to receive debugging log messages */
void isotp_user_debug(const char* message, ...) {
    va_list args;
    va_start(args, message);
    vprintf(message, args);
    va_end(args);
}
