#ifndef ISOTPC_H
#define ISOTPC_H

#include <stdio.h>
#include <string.h>

#ifdef __cplusplus
#include <stdint.h>
extern "C" {
#endif

#include "isotp_defines.h"
#include "isotp_config.h"
#include "isotp_user.h"

/**
 * @brief Struct containing the data for linking an application to a CAN instance.
 * The data stored in this struct is used internally and may be used by software programs
 * using this library.
 */
typedef struct IsoTpLink {
    /* sender parameters */
    uint32_t  send_arbitration_id; /* used to send (SF/FF/CF/FC) */

    /* message buffer (TX) */
    uint8_t  *send_buffer;
    uint32_t  send_buf_size;
    uint32_t  send_size;
    uint32_t  send_offset;

    /* multi-frame (TX) */
    uint8_t   send_sn;
    uint32_t  send_bs_remain;     /* Remaining block size (when peer advertises BS) */
    uint32_t  send_st_min_us;     /* Separation Time between consecutive frames (from peer FC) */
    uint8_t   send_wtf_count;     /* Maximum number of FC.Wait frame transmissions  */
    uint32_t  send_timer_st;      /* Used as "next CF due" ms tick */
    uint32_t  send_timer_bs;      /* (optional) time until reception of next FC */
    int       send_protocol_result;
    uint8_t   send_status;        /* internal TX state */

    /* receiver parameters */
    uint32_t  receive_arbitration_id; /* (optional) for apps that need it */

    /* message buffer (RX) */
    uint8_t  *receive_buffer;
    uint32_t  receive_buf_size;
    uint32_t  receive_size;
    uint32_t  receive_offset;

    /* multi-frame (RX) */
    uint8_t   receive_sn;         /* expected next CF SN (1..15, wraps) */
    uint8_t   receive_bs_count;   /* Block Size we advertise in FC (0 = infinite) */
    uint32_t  receive_timer_cr;   /* Time until next CF (peer must respect our STmin) */
    int       receive_protocol_result;
    uint8_t   receive_status;     /* internal RX state */

#if defined(ISO_TP_USER_SEND_CAN_ARG)
    void     *user_send_can_arg;
#endif

    /* ----------- CAN FD extensions (added) ----------- */
    uint8_t   can_fd;             /* 0: Classical, 1: CAN FD */
    uint8_t   tx_dl;              /* TX frame data length per frame (8/12/16/20/24/32/48/64) */
    uint8_t   rx_dl;              /* Learned from FF (RX frame data length) */
    uint8_t   padding_enable;     /* Pad frame to tx_dl when enabled */
    uint8_t   padding_value;      /* Padding byte value */
    uint8_t   ext_addr;           /* Extended addressing header present (0/1). If 1, one byte before PCI */
    uint8_t   brs;                /* Bit Rate Switch (hint for lower layer), 0/1 */
} IsoTpLink;

/* ---------- API ---------- */

/**
 * @brief Initialises the ISO-TP link object.
 *
 * @param link The IsoTpLink instance used for transceiving data.
 * @param sendid The CAN ID used to send data to other nodes.
 * @param sendbuf Pointer to a buffer to copy TX payload into (for multi-frame).
 * @param sendbufsize Size of TX buffer area.
 * @param recvbuf Pointer to RX buffer where reassembled data is placed.
 * @param recvbufsize Size of RX buffer area.
 */
void isotp_init_link(IsoTpLink *link, uint32_t sendid,
                     uint8_t *sendbuf, uint32_t sendbufsize,
                     uint8_t *recvbuf, uint32_t recvbufsize);

/**
 * @brief Optional configuration: enable/disable CAN FD and set tx_dl/brs.
 * @param enable 0=Classical, 1=CAN FD
 * @param tx_dl  Frame data length to use when sending (8..64 allowed set {8,12,16,20,24,32,48,64})
 * @param brs    1 to hint lower layer to use BRS for FD, else 0
 */
void isotp_config_can_fd(IsoTpLink *link, uint8_t enable, uint8_t tx_dl, uint8_t brs);

/**
 * @brief Optional configuration: enable padding and padding value.
 */
void isotp_config_padding(IsoTpLink *link, uint8_t enable, uint8_t pad);

/**
 * @brief Optional configuration: set Block Size we advertise in FC (as receiver).
 * 0 means unlimited (no periodic FC).
 */
void isotp_config_receiver_bs(IsoTpLink *link, uint8_t bs);

/**
 * @brief Polling function; call periodically to handle timeouts, send consecutive frames, etc.
 */
void isotp_poll(IsoTpLink *link);

/**
 * @brief Handle a received CAN frame (raw data field).
 * @param link Link instance
 * @param data CAN data field pointer
 * @param len  CAN data field length (Classical: 0..8, FD: 0..64)
 */
void isotp_on_can_message(IsoTpLink *link, const uint8_t *data, uint8_t len);

/**
 * @brief Send an ISO-TP payload. Single-frame sent immediately, multi-frame continues in poll().
 * @param link Link instance
 * @param payload Pointer to data (up to 4095 bytes in this compact implementation)
 * @param size Payload size in bytes
 * @return ISOTP_RET_OVERFLOW / ISOTP_RET_INPROGRESS / ISOTP_RET_OK / user shim error
 */
int isotp_send(IsoTpLink *link, const uint8_t payload[], uint32_t size);

/**
 * @brief Same as isotp_send but using a specific CAN ID (functional addressing, etc).
 */
int isotp_send_with_id(IsoTpLink *link, uint32_t id, const uint8_t payload[], uint32_t size);

/**
 * @brief Retrieve received PDU, if completed.
 * @param link Link instance
 * @param payload Destination buffer to copy into
 * @param payload_size Destination buffer size
 * @param out_size Output: actual reassembled payload size
 * @return ISOTP_RET_OK or ISOTP_RET_NO_DATA
 */
int isotp_receive(IsoTpLink *link, uint8_t *payload, const uint32_t payload_size, uint32_t *out_size);

#ifdef __cplusplus
}
#endif

#endif /* ISOTPC_H */
