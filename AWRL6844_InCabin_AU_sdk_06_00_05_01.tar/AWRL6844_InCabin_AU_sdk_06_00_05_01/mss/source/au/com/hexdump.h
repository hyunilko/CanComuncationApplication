/* ---------------------------------------------------------------------------
 *  hexdump.h - Lightweight, header-only hex/ASCII memory dump utility for C
 *
 *  API:
 *      void hexdump(const char *desc, const void *data, size_t size);
 *
 *      - desc : Optional text to print before the dump.
 *      - data : Pointer to memory to display.
 *      - size : Number of bytes to display.
 *
 *  Notes:
 *      - Marked static inline: each translation unit gets its own copy.
 *      - Pure ISO C (no platform-specific calls).
 *      - Printable ASCII [0x20..0x7E], else shown as '.'.
 * -------------------------------------------------------------------------*/
#ifndef HEXDUMP_H
#define HEXDUMP_H

#include <stdio.h>
#include <ctype.h>

static inline void hexdump(const char *desc, const void *addr, size_t size)
{
    size_t i, j;
    const unsigned char *pc = (const unsigned char*)addr;

    if (desc)
        printf("\r\n%s (%zu bytes):\n", desc, size);

    for (i = 0; i < size; i += 16)
    {
        // Print offset
        printf("%04zx  ", i);

        // Print hex bytes
        for (j = 0; j < 16; j++)
        {
            if (i + j < size)
                printf("%02X ", pc[i + j]);
            else
                printf("   ");
        }

        printf(" ");

        // Print ASCII
        for (j = 0; j < 16; j++)
        {
            if (i + j < size)
            {
                unsigned char ch = pc[i + j];
                printf("%c", (ch >= 0x20 && ch <= 0x7E) ? ch : '.');
            }
        }
        printf("\r\n");
    }
}

#endif /* HEXDUMP_H */
