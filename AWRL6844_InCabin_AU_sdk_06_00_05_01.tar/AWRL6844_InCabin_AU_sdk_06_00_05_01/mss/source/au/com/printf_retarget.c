#include <stdint.h>
#include <stddef.h>
#include <errno.h>

#include <source/mmw_cli.h>

static void put_bytes_via_uart(const char *buf, size_t len)
{
    const char *p = buf;
    for (size_t i = 0; i < len; ++i) {
        if (p[i] == '\n') {
            CLI_write("\r\n");
        } else {
            CLI_write("%c", p[i]);
        }
    }
}

int write(int fd, const char *buf, unsigned int count)
{
    if (fd == 1 || fd == 2) { // 1: stdout, 2: stderr
        if (buf == NULL) {
            errno = EINVAL;
            return -1;
        }
        put_bytes_via_uart(buf, count);
        return (int)count;
    }
    errno = EBADF;
    return -1;
}
