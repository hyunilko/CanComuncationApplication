#ifndef CONVERSION_H
#define CONVERSION_H

#include <stdint.h>
#include <string.h>

/* compile-time guard: this header assumes IEEE-754 32-bit float */
#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 201112L
    _Static_assert(sizeof(float) == 4, "conversion.h requires 32-bit float.");
#elif defined(__cplusplus) && __cplusplus >= 201103L
    static_assert(sizeof(float) == 4, "conversion.h requires 32-bit float.");
#endif

#ifdef __cplusplus
/*do this after the #includes*/
extern "C" {
#endif

/* -------------------- uint16 / uint32 big-endian -------------------- */
static inline void uint16_to_big_endian(uint16_t value, uint8_t *buffer) {
    buffer[0] = (uint8_t)((value >> 8) & 0xFF);
    buffer[1] = (uint8_t)(value & 0xFF);
}

static inline uint16_t big_endian_to_uint16(const uint8_t *buffer) {
    return ((uint16_t)buffer[0] << 8) | (uint16_t)buffer[1];
}

static inline void uint32_to_big_endian(uint32_t value, uint8_t *buffer) {
    buffer[0] = (uint8_t)((value >> 24) & 0xFF);
    buffer[1] = (uint8_t)((value >> 16) & 0xFF);
    buffer[2] = (uint8_t)((value >> 8)  & 0xFF);
    buffer[3] = (uint8_t)(value & 0xFF);
}

static inline uint32_t big_endian_to_uint32(const uint8_t *buffer) {
    return ((uint32_t)buffer[0] << 24) |
           ((uint32_t)buffer[1] << 16) |
           ((uint32_t)buffer[2] << 8)  |
           (uint32_t)buffer[3];
}

/* -------------------- uint16 / uint32 little-endian -------------------- */
static inline void uint16_to_little_endian(uint16_t value, uint8_t *buffer) {
    buffer[1] = (uint8_t)((value >> 8) & 0xFF);
    buffer[0] = (uint8_t)(value & 0xFF);
}

static inline uint16_t little_endian_to_uint16(const uint8_t *buffer) {
    return ((uint16_t)buffer[1] << 8) | (uint16_t)buffer[0];
}

static inline void uint32_to_little_endian(uint32_t value, uint8_t *buffer) {
    buffer[3] = (uint8_t)((value >> 24) & 0xFF);
    buffer[2] = (uint8_t)((value >> 16) & 0xFF);
    buffer[1] = (uint8_t)((value >> 8)  & 0xFF);
    buffer[0] = (uint8_t)(value & 0xFF);
}

static inline uint32_t little_endian_to_uint32(const uint8_t *buffer) {
    return ((uint32_t)buffer[3] << 24) |
           ((uint32_t)buffer[2] << 16) |
           ((uint32_t)buffer[1] << 8)  |
           (uint32_t)buffer[0];
}

/* -------------------- byte-swap helpers -------------------- */
static inline uint32_t swap_endian32(uint32_t value) {
    return ((value >> 24) & 0x000000FFu) |
           ((value >> 8)  & 0x0000FF00u) |
           ((value << 8)  & 0x00FF0000u) |
           ((value << 24) & 0xFF000000u);
}

static inline uint16_t swap_endian16(uint16_t value) {
    return (uint16_t)(((value >> 8) & 0x00FFu) |
                      ((value << 8) & 0xFF00u));
}

/* -------------------- float (IEEE-754, 32-bit) -------------------- */
/* note:
* - Float ↔ bytes conversion preserves bit patterns (including sign/NaN payloads).
* - Encodes/decodes in the specified endianness, regardless of platform endianness.
 */

static inline void float_to_big_endian(float value, uint8_t *buffer) {
    uint32_t bits;
    memcpy(&bits, &value, sizeof(bits));
    uint32_to_big_endian(bits, buffer);
}

static inline float big_endian_to_float(const uint8_t *buffer) {
    uint32_t bits = big_endian_to_uint32(buffer);
    float value;
    memcpy(&value, &bits, sizeof(value));
    return value;
}

static inline void float_to_little_endian(float value, uint8_t *buffer) {
    uint32_t bits;
    memcpy(&bits, &value, sizeof(bits));
    uint32_to_little_endian(bits, buffer);
}

static inline float little_endian_to_float(const uint8_t *buffer) {
    uint32_t bits = little_endian_to_uint32(buffer);
    float value;
    memcpy(&value, &bits, sizeof(value));
    return value;
}

#ifdef __cplusplus
}
#endif

#endif /* CONVERSION_H */

