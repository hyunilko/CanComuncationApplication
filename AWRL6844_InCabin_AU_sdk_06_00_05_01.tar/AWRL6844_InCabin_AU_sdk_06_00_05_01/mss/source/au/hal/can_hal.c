/*
 * Copyright (C) 2025 AU Inc.
 *
 * Author   : AU
 * Desc     : The CAN hal acts as a bridge between the driver hal layer and the driver layer.
 */

/**************************************************************************
 *************************** Include Files ********************************
 **************************************************************************/

#include <stdio.h>
#include <string.h>

#include <kernel/dpl/DebugP.h>
#include <kernel/dpl/HwiP.h>
#include <kernel/dpl/AddrTranslateP.h>
#include <kernel/dpl/SemaphoreP.h>
#include <drivers/mcan.h>

/*OS Include Files. */
#include "FreeRTOS.h"
#include "task.h"
#include <semphr.h>

#include "ti_drivers_config.h"
#include "ti_drivers_open_close.h"
#include "ti_board_open_close.h"

#include "hal/can_hal.h"
#include "mw/can_mw.h"
#include "com/hexdump.h"

#include "mw/can/can_isotp.h"
#include "mw/can/can_custom_tp.h"

/* +++ MCAN Defines */
#define APP_MCAN_BASE_ADDR (CONFIG_MCAN0_BASE_ADDR)
#define APP_MCAN_INTR_NUM (CONFIG_MCAN0_INTR)
#define APP_MCAN_LOOPBACK_MODE_ENABLE (FALSE)

/* Allocate Message RAM memory section to filter elements, buffers, FIFO */
/* Maximum STD Filter Element can be configured is 128 */
#define APP_MCAN_STD_ID_FILTER_CNT (1U)
/* Maximum EXT Filter Element can be configured is 64 */
#define APP_MCAN_EXT_ID_FILTER_CNT (0U)
/* Maximum TX Buffer + TX FIFO, combined can be configured is 32 */
#define APP_MCAN_TX_BUFF_CNT (3U)
#define APP_MCAN_TX_FIFO_CNT (0U)
/* Maximum TX Event FIFO can be configured is 32 */
#define APP_MCAN_TX_EVENT_FIFO_CNT (0U)
/* Maximum RX FIFO 0 can be configured is 64 */
#define APP_MCAN_FIFO_0_CNT (32U) // 0U -> 32U

/* Maximum RX FIFO 1 can be configured is 64 and
  rest of the memory is allocated to RX buffer which is again of max size 64 */
#define APP_MCAN_FIFO_1_CNT (0U)
/* Standard Id configured in this app */
#define APP_MCAN_STD_ID (0xC0U)
#define APP_MCAN_STD_ID_MASK (0x7FFU)
#define APP_MCAN_STD_ID_SHIFT (18U)
#define APP_MCAN_EXT_ID_MASK (0x1FFFFFFFU)

/* Semaphore to indicate transfer completion */
static SemaphoreP_Object gMcanTxDoneSem, gMcanRxDoneSem;
static HwiP_Object       gMcanHwiObject;
static uint32_t          gMcanBaseAddr;


#define CAN_TASK_SIZE (10U * 1024U)
#define CAN_TASK_PRIORITY (4U)

#define APP_MCAN_DEVICE_ID_SHIFT (8U) // bit 10~8
#define APP_MCAN_MSG_ID_MASK (0xFFU)  // bit 7~0
static uint8_t gDeviceId = 0U;

static StackType_t gCanRcvProcessTaskStack[CAN_TASK_SIZE] __attribute__((aligned(32)));
static StaticTask_t gCanRcvProcessTaskObj;
static TaskHandle_t gCanRcvProcessTask;

static void canRcvProcessTask(void* arg);


/* +++ MCAN Static Function Declarations */
static int32_t App_mcanTransmit(uint32_t bufNum, uint32_t id, uint8_t * data, uint32_t len);
static void App_mcanIntrISR(void *arg);
static void App_mcanConfig(Bool enableInternalLpbk);
static void App_mcanInitMsgRamConfigParams(MCAN_MsgRAMConfigParams *msgRAMConfigParams);
static void App_mcanEnableIntr(void);
static void App_mcanConfigTxMsg(MCAN_TxBufElement *txMsg, uint32_t id, uint32_t fdf, uint8_t * data);
static void App_mcanInitStdFilterElemParams(MCAN_StdMsgIDFilterElement *stdFiltElem, uint32_t bufNum);


/* +++ MCAN Static Function Definitions */
void App_mcanInit()
{
    int32_t                 status = SystemP_SUCCESS;
    HwiP_Params             hwiPrms;

    /* Construct Tx/Rx Semaphore objects */
    status = SemaphoreP_constructBinary(&gMcanTxDoneSem, 0);
    DebugP_assert(SystemP_SUCCESS == status);
    status = SemaphoreP_constructBinary(&gMcanRxDoneSem, 0);
    DebugP_assert(SystemP_SUCCESS == status);

    /* Register interrupt */
    HwiP_Params_init(&hwiPrms);
    hwiPrms.intNum      = APP_MCAN_INTR_NUM;
    hwiPrms.callback    = &App_mcanIntrISR;
    status              = HwiP_construct(&gMcanHwiObject, &hwiPrms);
    DebugP_assert(status == SystemP_SUCCESS);

    /* Assign MCAN instance address */
    gMcanBaseAddr = (uint32_t) AddrTranslateP_getLocalAddr(APP_MCAN_BASE_ADDR);

    /* Configure MCAN module, Enable External LoopBack Mode */
    App_mcanConfig(APP_MCAN_LOOPBACK_MODE_ENABLE);

    /* Enable Interrupts */
    App_mcanEnableIntr();

    gCanRcvProcessTask = xTaskCreateStatic( canRcvProcessTask,
                                    "canRcvProcessTask",
                                    CAN_TASK_SIZE,
                                    NULL,
                                    CAN_TASK_PRIORITY,
                                    gCanRcvProcessTaskStack,
                                    &gCanRcvProcessTaskObj);
    configASSERT(gCanRcvProcessTask != NULL);

    return;
}

static inline int _mcan_tx_busy(uint32_t bufNum) {
    /* If the Request Pending bit is set, it is still being transmitted by the HW. */
    uint32_t pend = MCAN_getTxBufReqPend(gMcanBaseAddr);
    return ((pend >> bufNum) & 0x1U) ? 1 : 0;
}

static int32_t App_mcanTransmit(uint32_t bufNum, uint32_t id, uint8_t * data, uint32_t len)
{
    MCAN_TxBufElement txMsg;
    uint32_t fdf = MCAN_isFDOpEnable(gMcanBaseAddr);

    uint32_t spin = 0U;
    while (_mcan_tx_busy(bufNum)) {
        if (spin++ > 3000U) {
            return -11;
        }
        ClockP_usleep(1);
    }

    App_mcanConfigTxMsg(&txMsg, id, fdf, data);

    if (MCAN_txBufTransIntrEnable(gMcanBaseAddr, bufNum, (uint32_t)TRUE) != CSL_PASS) {
        return -1;
    }

    MCAN_writeMsgRam(gMcanBaseAddr, MCAN_MEM_TYPE_BUF, bufNum, &txMsg);

    if (MCAN_txBufAddReq(gMcanBaseAddr, bufNum) != CSL_PASS) {
        return -11; /* EAGAIN */
    }

    return SystemP_SUCCESS;
}

static void App_mcanIntrISR(void *arg)
{
    uint32_t intrStatus = MCAN_getIntrStatus(gMcanBaseAddr);
    MCAN_clearIntrStatus(gMcanBaseAddr, intrStatus);

    if (intrStatus & MCAN_INTR_SRC_TRANS_COMPLETE) {
        SemaphoreP_post(&gMcanTxDoneSem);
    }

    uint32_t rxWakeMask =
        MCAN_INTR_SRC_RX_FIFO0_NEW_MSG     |
        MCAN_INTR_SRC_RX_FIFO0_WATERMARK   |
        MCAN_INTR_SRC_RX_FIFO0_FULL        |
        MCAN_INTR_SRC_RX_FIFO0_MSG_LOST;

    if (intrStatus & rxWakeMask) {
        SemaphoreP_post(&gMcanRxDoneSem);
    }
}

static void App_mcanConfig(Bool enableInternalLpbk)
{
    MCAN_StdMsgIDFilterElement stdFiltElem[APP_MCAN_STD_ID_FILTER_CNT] = {0U};
    MCAN_InitParams            initParams = {0U};
    MCAN_ConfigParams          configParams = {0U};
    MCAN_MsgRAMConfigParams    msgRAMConfigParams = {0U};
    MCAN_BitTimingParams       bitTimes = {0U};
    uint32_t                   i;

    /* Initialize MCAN module initParams */
    MCAN_initOperModeParams(&initParams);
    /* CAN FD Mode and Bit Rate Switch Enabled */
    initParams.fdMode          = TRUE;
    initParams.brsEnable       = TRUE;

    /* Initialize MCAN module Global Filter Params */
    MCAN_initGlobalFilterConfigParams(&configParams);

    /* Initialize MCAN module Bit Time Params */
    /* Configuring default 1Mbps and 5Mbps as nominal and data bit-rate resp */
    MCAN_initSetBitTimeParams(&bitTimes);

    /* Initialize MCAN module Message Ram Params */
    App_mcanInitMsgRamConfigParams(&msgRAMConfigParams);

    /* Initialize Filter element to receive msg, should be same as tx msg id */
    for (i = 0U; i < APP_MCAN_STD_ID_FILTER_CNT; i++)
    {
        App_mcanInitStdFilterElemParams(&stdFiltElem[i], i);
    }
    /* wait for memory initialization to happen */
    while (FALSE == MCAN_isMemInitDone(gMcanBaseAddr))
    {}

    /* Put MCAN in SW initialization mode */
    MCAN_setOpMode(gMcanBaseAddr, MCAN_OPERATION_MODE_SW_INIT);
    while (MCAN_OPERATION_MODE_SW_INIT != MCAN_getOpMode(gMcanBaseAddr))
    {}

    /* Initialize MCAN module */
    MCAN_init(gMcanBaseAddr, &initParams);
    /* Configure MCAN module Global Filter */
    MCAN_config(gMcanBaseAddr, &configParams);
    /* Configure Bit timings */
    MCAN_setBitTime(gMcanBaseAddr, &bitTimes);
    /* Configure Message RAM Sections */
    MCAN_msgRAMConfig(gMcanBaseAddr, &msgRAMConfigParams);
    /* Set Extended ID Mask */
    MCAN_setExtIDAndMask(gMcanBaseAddr, APP_MCAN_EXT_ID_MASK);

    /* Configure Standard ID filter element */
    for (i = 0U; i < APP_MCAN_STD_ID_FILTER_CNT; i++)
    {
        MCAN_addStdMsgIDFilter(gMcanBaseAddr, i, &stdFiltElem[i]);
    }
    if (TRUE == enableInternalLpbk)
    {
        MCAN_lpbkModeEnable(gMcanBaseAddr, MCAN_LPBK_MODE_INTERNAL, TRUE);
    }

    /* Take MCAN out of the SW initialization mode */
    MCAN_setOpMode(gMcanBaseAddr, MCAN_OPERATION_MODE_NORMAL);
    while (MCAN_OPERATION_MODE_NORMAL != MCAN_getOpMode(gMcanBaseAddr))
    {}

    return;
}

static void App_mcanConfigTxMsg(MCAN_TxBufElement *txMsg, uint32_t id, uint32_t fdf, uint8_t * data)
{
    MCAN_initTxBufElement(txMsg);
    txMsg->id  = ((id & MCAN_STD_ID_MASK) << MCAN_STD_ID_SHIFT);
    txMsg->dlc = MCAN_DATA_SIZE_64BYTES;
    txMsg->fdf = fdf;
    txMsg->brs = TRUE;
    txMsg->xtd = FALSE;

    memset(txMsg->data, 0, MCAN_MAX_PAYLOAD_BYTES);
    memcpy(txMsg->data, data, MCAN_MAX_PAYLOAD_BYTES);
}

static void App_mcanInitStdFilterElemParams(MCAN_StdMsgIDFilterElement *f, uint32_t /*bufNum*/)
{
    f->sfid1 = (gDeviceId << APP_MCAN_DEVICE_ID_SHIFT);  /* ddd00000000b Top 3 bits (10:8) = Compare only deviceId */
    f->sfid2 = 0x700;                                   /* 11100000000b */

    f->sfec  = MCAN_STD_FILT_ELEM_FIFO0;                /* FIFO0 Routing */
    f->sft   = MCAN_STD_FILT_TYPE_CLASSIC;
}

static void App_mcanEnableIntr(void)
{
    MCAN_enableIntr(gMcanBaseAddr, MCAN_INTR_MASK_ALL, (uint32_t)TRUE);
    MCAN_enableIntr(gMcanBaseAddr,
                    MCAN_INTR_SRC_RES_ADDR_ACCESS, (uint32_t)FALSE);
    /* Select Interrupt Line 0 */
    MCAN_selectIntrLine(gMcanBaseAddr, MCAN_INTR_MASK_ALL, MCAN_INTR_LINE_NUM_0);
    /* Enable Interrupt Line */
    MCAN_enableIntrLine(gMcanBaseAddr, MCAN_INTR_LINE_NUM_0, (uint32_t)TRUE);

    return;
}

static void App_mcanInitMsgRamConfigParams(MCAN_MsgRAMConfigParams *msgRAMConfigParams)
{
    int32_t status;
    MCAN_initMsgRamConfigParams(msgRAMConfigParams);

    msgRAMConfigParams->lss           = APP_MCAN_STD_ID_FILTER_CNT;
    msgRAMConfigParams->lse           = APP_MCAN_EXT_ID_FILTER_CNT;
    msgRAMConfigParams->txBufCnt      = APP_MCAN_TX_BUFF_CNT;
    msgRAMConfigParams->txFIFOCnt     = APP_MCAN_TX_FIFO_CNT;
    msgRAMConfigParams->txBufMode     = MCAN_TX_MEM_TYPE_BUF;
    msgRAMConfigParams->txEventFIFOCnt= APP_MCAN_TX_EVENT_FIFO_CNT;

    msgRAMConfigParams->rxFIFO0Cnt    = APP_MCAN_FIFO_0_CNT;
    msgRAMConfigParams->rxFIFO0OpMode = MCAN_RX_FIFO_OPERATION_MODE_BLOCKING;
    msgRAMConfigParams->rxFIFO1Cnt    = APP_MCAN_FIFO_1_CNT;
    msgRAMConfigParams->rxFIFO1OpMode = MCAN_RX_FIFO_OPERATION_MODE_BLOCKING;

    msgRAMConfigParams->rxBufElemSize    = MCAN_ELEM_SIZE_64BYTES;
    msgRAMConfigParams->rxFIFO0ElemSize  = MCAN_ELEM_SIZE_64BYTES;
    msgRAMConfigParams->rxFIFO1ElemSize  = MCAN_ELEM_SIZE_64BYTES;
    msgRAMConfigParams->txBufElemSize    = MCAN_ELEM_SIZE_64BYTES;

    status = MCAN_calcMsgRamParamsStartAddr(msgRAMConfigParams);
    DebugP_assert(status == CSL_PASS);
}

static inline uint8_t mcandlc_to_len(uint8_t dlc)
{
    static const uint8_t map[16] = {
        0,1,2,3,4,5,6,7,8,12,16,20,24,32,48,64
    };
    return map[dlc & 0xF];
}

static void canRcvProcessTask(void* arg)
{
    MCAN_RxBufElement rxMsg;
    MCAN_RxFIFOStatus rx_fifo_status_f0;

    for (;;) {
        SemaphoreP_pend(&gMcanRxDoneSem, SystemP_WAIT_FOREVER);

    rx_fifo_status_f0.num = MCAN_RX_FIFO_NUM_0;
    MCAN_getRxFIFOStatus(gMcanBaseAddr, &rx_fifo_status_f0);

        while (rx_fifo_status_f0.fillLvl > 0U) {

            MCAN_readMsgRam(gMcanBaseAddr,
                            MCAN_MEM_TYPE_FIFO,
                            0U, /* bufNum 미사용 */
                            MCAN_RX_FIFO_NUM_0,
                            &rxMsg);

            //printf("canRcvProcessTask 0x%02x 0x%02x 0x%02x 0x%02x\n", rxMsg.data[0], rxMsg.data[1], rxMsg.data[2], rxMsg.data[3]);

            uint32_t can_id = (rxMsg.id >> APP_MCAN_STD_ID_SHIFT) & APP_MCAN_STD_ID_MASK;
            uint8_t  len    = mcandlc_to_len(rxMsg.dlc);

            //hexdump("canRcvProcessTask", rxMsg.data, len);

        #ifdef ISO_TP_ENABLE
            can_iso_tp_receive_mgr(can_id, rxMsg.data, len);
        #else
            can_custom_tp_receive_mgr(rxMsg.data);
        #endif
            /* FIFO ACK */
            MCAN_writeRxFIFOAck(gMcanBaseAddr, MCAN_RX_FIFO_NUM_0, rx_fifo_status_f0.getIdx);

            rx_fifo_status_f0.num = MCAN_RX_FIFO_NUM_0;
            MCAN_getRxFIFOStatus(gMcanBaseAddr, &rx_fifo_status_f0);
        }
    }
}

void can_set_device_id(uint8_t device_id){
    gDeviceId = device_id;
}

int32_t can_hal_send(uint32_t tx_id, uint8_t* buffer, int32_t size)
{
    //hexdump("can_hal_send", buffer, 4);
    //printf("can_hal_send tx_id: 0x%02x buffer: 0x%02x 0x%02x 0x%02x\n", tx_id, buffer[0], buffer[1], buffer[2]);
    uint32_t can_tx_id = (gDeviceId << APP_MCAN_DEVICE_ID_SHIFT) | (tx_id & APP_MCAN_MSG_ID_MASK);
    return App_mcanTransmit(0, can_tx_id, buffer, size);
}
