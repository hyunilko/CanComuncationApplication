/*
 * Copyright (C) 2025 AU Inc.
 *
 * Author   : AU
 * Desc     : MCAN driver interface layer.
 *
 * Note     : To initiate MCAN Driver interface, refer to au_dpl_echo_test()
 */

#ifndef _CAN_HAL_H_
#define _CAN_HAL_H_

#include <stdint.h>

void App_mcanInit();
void can_set_device_id(uint8_t device_id);
int32_t can_hal_send(uint32_t tx_id, uint8_t* msg_buffer, int32_t msg_size);

#endif
